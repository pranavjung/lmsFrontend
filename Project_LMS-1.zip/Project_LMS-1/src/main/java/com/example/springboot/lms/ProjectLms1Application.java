package com.example.springboot.lms;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class ProjectLms1Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjectLms1Application.class, args);
	}
   
}
